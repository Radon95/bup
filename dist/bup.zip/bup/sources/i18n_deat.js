var i18n_deat = {

'_code': 'de-AT',
'_name': 'Deutsch (Österreich)',
'_fallback': 'de',

'game point': 'Satzball',
'match point': 'Matchball',
'scoredisplay:Game Point': 'Satzball',
'scoredisplay:Match Point': 'Matchball',
'eventsheet:Notes': 'Anmerkungen:',

};

