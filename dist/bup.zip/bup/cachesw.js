self.addEventListener("install",function(){});
//# sourceMappingURL=cachesw.js.map